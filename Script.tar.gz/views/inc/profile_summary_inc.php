<!-- PopOut User -->
		<div id="container_popout"></div>
		<div class="popoutUser" id="content_popout">
			<div class="wrap_popout">
				<div class="title_popout">
					<span class="textPopout"><?php echo $_SESSION['LANG']['summary_of_profile']; ?></span>
					<div class="close_popout"></div>
				</div><!-- title_popout -->
				<div class="content_user"></div><!-- content user -->
			</div><!-- wrap popout -->
		</div><!-- popout user -->
		